Admin:
username:admin
password:password123

Users:
user:jude
password:password

user:adones
password:password