<?php
    include "header.php";
    include "navbar.php";
?>

<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="contact_style.css">
</head>

<body>
    <div class="flex-container-background">
        <div class="flex-container-heading">
            <h1 id="contact">Contact Us</h1>
        </div>

        <div class="flex-container" style="border-bottom: 0;
                                           border-top-left-radius: 10px;
                                           border-top-right-radius: 10px;">
            <div class="flex-item">
                <h1 id="sub-contact">General Contact</h1>
                <p id="sub-contact">
                    Toll-Free: 1111-111-1111<br>
                    Phone: 222-222-2222<br>
                    Fax: 333-333-3333<br>
                    Email: suarez081119@gmail.com
                </p>
            </div>
        </div>

        <div class="flex-container" style="border-top: 0;
                                           border-bottom-left-radius: 10px;
                                           border-bottom-right-radius: 10px;">
        </div>
    </div>

</body>
</html>
