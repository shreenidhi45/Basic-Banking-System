<?php
    include "header.php";
    include "navbar.php";
    include "connect.php";
?>

<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="news_style.css">
</head>

<body>
    <div class="flex-container">
        
             <h1>No news available ! Please post some.</h1>
           
    </div>

</body>
</html>
